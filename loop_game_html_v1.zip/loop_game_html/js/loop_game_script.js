let nftData = `{"nfts":[{"id":1,"name":"Pallbearer","type":"villains","image":"images/my_heros1.png","faction":"Red","tier":5,"tokenId":563,"isOnSale":true,"sellPrice":3243253,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43434232,"rating":2,"level":"latest","description":"Named Gary, Pallbearer started life born into a zoo somewhere in the midwest. He was loved by the keepers and adored by the public. Then, one day, a pharmaceutical company, on the pretense of simply taking a small sample of hair, kidnapped him and whisked him away to their secret laboratory. They had just discovered a powerful anti-aging drug, and as all their supplies had been lost in the escape of a previous animal subject, they were desperate to re-create it. This time, in an attempt to control the animal, they hooked up an elaborate system of tubes to control the intake of the drug. The formula, though, wasn’t quite right when they ran their first trial. Bolstered by the drug, Pallbearer broke free… And has now sworn vengeance on those who harmed him."},{"id":2,"name":"Redtail","type":"villains","image":"images/my_heros1.png","faction":"Blue","tier":2,"tokenId":63,"isOnSale":false,"sellPrice":0,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":0,"rating":3,"level":"latest","description":"The true name of Redtail is unknown, as are most things about him. A trickster by nature, he possesses a wide range of illusory abilities, possibly related to the same powers inherited by C.O.M.A. (and indeed, he has claimed to be from the same zoo, though he’s separately claimed to be from a distant plane of existence, New York, and Paris). His tail, of course, isn’t red, except for when he takes on the form of a red squirrel. Speaking to him is rarely encouraged, though punching him doesn’t work that well either, as he’s rarely standing where he seems to be."},{"id":3,"name":"Specimen V","faction":"Red","image":"images/my_heros1.png","type":"villains","tier":1,"tokenId":53,"isOnSale":true,"sellPrice":3243,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43324232,"rating":3,"level":"latest","description":"Captured from the deep ocean, Specimen V got his name from the small label taped to the outside of his tank. Of course, he was only able to read this after he escaped… Which he did many times. Every time, the keepers put him back, but every time, he was able to gain a bit more knowledge of his surroundings. Finally, he located a number of replacement limbs for an undersea robot that the scientists were building. Seizing on his chance, while the scientists slept one night, he escaped his tank, amputated his own limbs and attached the robot limbs in their place, and broke out into the darkness"},{"id":4,"name":"Kingsnake","type":"villains","image":"images/my_heros1.png","faction":"Green","tier":3,"tokenId":263,"isOnSale":false,"sellPrice":0,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43443232,"rating":3,"description":"A lowly milk snake used to being chased by angry humans, this creature was little more than a wild animal, living, unbeknownst to him, on the grounds of a hyperloop testing facility. One day, while slithering after a mouse, Kingsnake accidentally slipped through a vent and inside the building. There, he fell into a neodymium infusion device, and found himself blasted with electricity and metal. When he awoke, he was being nursed back to life in a veterinary hospital… With a great deal of metal surrounding him. When he escaped, he had tasted blood… And knew that he intended to make the human race pay."},{"id":5,"name":"Pollux","type":"villains","image":"images/my_heros1.png","faction":"Green","tier":3,"tokenId":263,"isOnSale":false,"sellPrice":0,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43443232,"rating":3,"level":"low_price","description":"Pollux is a hairless guinea pig that was a product of the experiments by the Silver Crow. She was infused with psychic powers from  a piece of a krytron crystal from Starling’s home planet, allowing her to levitate and interact with objects via telekinesis. The more sunlight she is exposed to, the more powerful (and red) she becomes: she is currently trying to learn the secrets of mind-control."},{"id":6,"name":"Ninth Life","type":"hero","image":"images/my_heros1.png","faction":"Green","tier":3,"tokenId":263,"isOnSale":false,"sellPrice":0,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43443232,"rating":3,"level":"low_price","description":"Captured off the street by a pharmaceutical company, Francis the cat was immediately put into an animal testing facility that was working on developing an anti-aging cream. Little did they know that they had developed a formula that went above and beyond their wildest dreams. When they discovered their success, they put him through a grueling series of tests to determine just how well it worked. He came out the other side unscathed, escaped, and now works to ensure that no others suffer in the same way that he did"},{"id":7,"name":"Ninth Life","type":"hero","image":"images/my_heros1.png","faction":"Green","tier":3,"tokenId":263,"isOnSale":false,"sellPrice":0,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43443232,"rating":2,"level":"high_price","description":"Captured off the street by a pharmaceutical company, Francis the cat was immediately put into an animal testing facility that was working on developing an anti-aging cream. Little did they know that they had developed a formula that went above and beyond their wildest dreams. When they discovered their success, they put him through a grueling series of tests to determine just how well it worked. He came out the other side unscathed, escaped, and now works to ensure that no others suffer in the same way that he did"},{"id":8,"name":"Croc of Mystic Arts (C.O.M.A.)","type":"hero","image":"images/my_heros1.png","faction":"Green","tier":3,"tokenId":263,"isOnSale":false,"sellPrice":0,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43443232,"rating":3,"level":"high_price","description":"Named Larry by the doting zookeepers, this lazy crocodile thought that he had everything. He could lay in the sun while visitors gazed at him in wonder, could eat when he wanted, and had the best medical care that an animal could want. Then, the wizards arrived. He never found out who they were, but when two magicians came crashing through the zoo in an inter-dimensional battle, Larry was temporarily trapped between two (or more, it was rather fuzzy) separate dimensions. The strain nearly tore him apart, but when he emerged from the other side, he found himself endowed with a host of inter-dimensional powers."},{"id":9,"name":"Sol","type":"hero","image":"images/my_heros1.png","faction":"Green","tier":3,"tokenId":263,"isOnSale":false,"sellPrice":0,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43443232,"rating":3,"level":"high_price","description":"Brought to Earth with the arrival of Starling, Sol has been the superhero’s trusted companion for many years. Due to his unearthly origin, he has the benefits of flight, laser vision, x-ray vision, and an extended lifespan, among other super-qualities."},{"id":10,"name":"Scarab","type":"hero","image":"images/my_heros1.png","faction":"Green","tier":3,"tokenId":263,"isOnSale":false,"sellPrice":0,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43443232,"rating":3,"level":"high_price","description":"While the Black Beetle is away on missions, Scarab is tasked with the defense of the Beetle Base, their secret hideaway. Scarab trains alongside his master, but rarely travels outside of the hideaway’s safety. They take great pride on being all-natural and self-taught in multiple martial arts."},{"id":11,"name":"Tempo","type":"hero","image":"images/my_heros1.png","faction":"Green","tier":3,"tokenId":263,"isOnSale":false,"sellPrice":0,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43443232,"rating":3,"level":"high_price","description":"Tempo is Monarch’s sole pet, gifted with the ironic power of super-speed. Whatever strange forces have affected their master seemed to have altered them on an atomic level over time, causing them to share in the slipspace movement like Monarch has."},{"id":12,"name":"Horizon","type":"hero","image":"images/my_heros1.png","faction":"Green","tier":3,"tokenId":263,"isOnSale":false,"sellPrice":0,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43443232,"rating":2,"level":"high_price","description":"The Marked Titan selected Horizon as his pet to assist on some missions, often flying incognito above a site soon to be infiltrated. The masterful training and teamwork have made both of them an incredible duo, and lets Horizon take the spot of most 'on-the-job' experience of anyone on this team."},{"id":13,"name":"Spitfire","type":"hero","image":"images/my_heros1.png","faction":"Green","tier":3,"tokenId":263,"isOnSale":false,"sellPrice":0,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43443232,"rating":1,"level":"high_price","description":"Sentinel was the first successful clinical test subject of Ox-Head's first ventures into Gamma radiation. During the process, Sentinel grew larger and denser, developing an enormous amount of muscle mass and slowly tinging green over a short period of time. Before long, Sentinel was both the size and weight of a cat, and ever since has been following in the footsteps of their master Ox-Head."},{"id":14,"name":"Euphrates","type":"hero","image":"images/my_heros1.png","faction":"Green","tier":3,"tokenId":263,"isOnSale":false,"sellPrice":0,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43443232,"rating":3,"level":"high_price","description":"Deep within the heart of the Euphrates river, a hidden island lies shrouded in fog. Living there, secretly watching the humans, was a race of people more powerful than most humans could dare to imagine. One day, poachers from South America crashed their plane on the island, scattering their animals there. One of the tigers who survived was rescued by the crown princess, Tigris, who named the creature after the beloved Euphrates river, and the companion river to her own namesake. They became fast friends, with Euphrates the tiger soon taking on many of the same characteristics of that royal race."},{"id":15,"name":"Hard Drive","type":"hero","image":"images/my_heros1.png","faction":"Green","tier":3,"tokenId":263,"isOnSale":false,"sellPrice":0,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43443232,"rating":3,"level":"high_price","description":"Fred the rhino had once roamed the plains of Africa, but had been captured and taken to a zoo for conservation when he was on the cusp of adulthood. He never really understood how it could be for his own good, and sought to escape captivity at every step. When a pair of dueling wizards came crashing through his zoo and damaged his cage, he fled. With guards hot on his tail, he found refuge in a suburban garage… A garage that just happened to belong to a particularly mad scientist with a thing for cybernetics. Fred was subsequently put through a series of experiments, eventually escaping as the hero Hard Drive, alongside the mad scientists’s own son, Floppy Disk, who had also been used for experiments."},{"id":16,"name":"Jackalope","type":"hero","image":"images/my_heros1.png","faction":"Green","tier":3,"tokenId":263,"isOnSale":false,"sellPrice":0,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43443232,"rating":2,"level":"high_price","description":"One of the two infamous dueling wizards, Zeck, originally earned his powers from a much older wizard of the same name, who would impart his powers with a simple invocation of his title. When the battle ended, and Zeck found himself on the open plains of Kansas, he noticed a small rabbit gazing at him intensely. Rather on a whim, Zeck cast out a burst of power, giving the rabbit the ability to speak. It immediately declared that it wished to come with him, and after a bit of deliberation, Zeck agreed. The rabbit took on the mythical name of Jackalope, and has been with Zeck ever since."},{"id":17,"name":"Fletcher","type":"hero","image":"images/my_heros1.png","faction":"Green","tier":3,"tokenId":263,"isOnSale":false,"sellPrice":0,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43443232,"rating":3,"level":"high_price","description":"One of the only men with wealth to rival Killian Kerrigan, Oscar Natterson was wont to tour the landscape of Technotopia for all the pleasures that life had to offer, including, one day, a facility designed to breed show hawks. He became particularly attracted to a hawk named Fletcher, and purchased it on the spot. Upon returning to his penthouse, Oscar let Fletcher in on his secret: He was also the archer-hero Longshot. With Fletcher’s keen eyesight, and the occasional feather donated to help fletch an arrow, the two form an inseparable bond"},{"id":18,"name":"Maelstrom","type":"hero","image":"images/my_heros1.png","faction":"Green","tier":3,"tokenId":263,"isOnSale":false,"sellPrice":0,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43443232,"rating":3,"level":"high_price","description":"Deep within the Atlantic ocean, far beyond the range of any sensors of man, lies a hidden settlement. Sharing ancestors with the Euphrates River community, but having adapted to underwater life, they are a powerful and mysterious race, endowed with many abilities. One of them, taking the name Odysseus after the great explorer, set forth to protect the reefs of coral that, in turn, protected his colony. On one of these trips, he came upon a small seahorse, who, unbeknownst to him, had swallowed one of the stones that formed the foundation of their civilization. When a great white shark attacked, before Odysseus could do a thing, Maelstrom created a great whirlpool that sucked the creature down into an ocean trench. Since then, Odysseus and Maelstrom have been inseparable. "},{"id":19,"name":"Cumulonimbus","type":"hero","image":"images/my_heros1.png","faction":"Green","tier":3,"tokenId":263,"isOnSale":false,"sellPrice":0,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43443232,"rating":3,"level":"high_price","description":"Growing up in a distant village of vikings, many thousands of years before electricity was generated by anything other than lightning, Vlad the goat was scheduled for slaughter. Upon learning this fact, and not particularly desirous of being turned into a meat pie, he fought his way to freedom with nothing but the two horns on his head. This impressed several nearby ravens, who, in turn, reported the find to their master, the king of the original tribe of Hidden Warriors. His son, Thunderhead, immediately set forth and took the goat as his own, endowing him with both power and long life. In modern times, Vlad has taken on the name Cumulonimbus, after the cloud that can generate… Well… Lightning."},{"id":20,"name":"Thorax","type":"hero","image":"images/my_heros1.png","faction":"Green","tier":3,"tokenId":263,"isOnSale":false,"sellPrice":0,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43443232,"rating":3,"level":"high_price","description":"Specimen 3274 was, in many ways, utterly unremarkable, save for the fact that he had been captured by a particular pharmaceutical company that had been plagued with a recent bout of escaped test subjects. This time, they believed themselves to have the perfect solution: Testing on creatures too small to break through concrete. This, though, proved to be a mistake, when one of the scientists accidentally left the lid of Specimen 3274’s tank open just a crack. It quickly raced free, where, upon stumbling into a group of school children visiting the lad, rather accidentally bit the aptly-named Tony Webster on the foot. Tony, being an unexcitable sort of kid, didn’t squash the spider, and instead took it home for study. He was able to understand many of his own powers by watching the powers of Specimen 3274, who he soon named Thorax, after the brilliant colors displayed by the spider on that part of his body."},{"id":21,"name":"Dice-Slice","type":"hero","image":"images/my_heros1.png","faction":"Green","tier":3,"tokenId":263,"isOnSale":false,"sellPrice":0,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43443232,"rating":3,"level":"high_price","description":"Upon losing a third test subject into the wild, the pharmaceutical company was growing angry (though, in fairness, having avoided lawsuits no fewer than three times, it really couldn’t complain). It captured a wolverine, threw it into a deep, dark cell, pumped it full of a dozen different chemicals, and then poured cement around the cell and sat back to see what would happen. The result was not pretty, and what made it worse was that one of their construction workers pouring the cement, by the name of Paul, wound up getting locked in with Specimen 3741. In the chaos, when Paul was injured quite badly, some of the chemicals dripped into his wounds, endowing him with the same powers. Together, the two of them carved their way to freedom, and soon escaped into the world together"},{"id":22,"name":"Quickpad","type":"hero","image":"images/my_heros1.png","faction":"Green","tier":3,"tokenId":263,"isOnSale":false,"sellPrice":0,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43443232,"rating":3,"level":"high_price","description":"Coming from a long line of royal panthers, Quickpad was chosen to ascend to the throne when his father was killed on a mission with Shadowcat, the crown prince of Maritor, a country deep within the heart of Africa. Trained from birth for his eventual mission, Quickpad was more than ready to take up the mantle, and was soon taken by Shadowcat to a grove of trees deep within the jungle. There, he was presented to the Archangel Michael, where he was granted immense powers, including a mental bond between himself and Shadowcat, enhanced reflexes, speed, strength, senses, and much more."},{"id":23,"name":"Sunbeam","type":"hero","image":"images/my_heros1.png","faction":"Green","tier":3,"tokenId":263,"isOnSale":false,"sellPrice":0,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43443232,"rating":3,"level":"high_price","description":"Sunbeam started off life as a simple squirrel, living in a city park where he did his best to collect acorns and hide them from both other squirrels and park quests alike. Suddenly, though, two dueling wizards came crashing through the park, and a wide array of multiple dimensions were shown to him. One of them caught his eye: An immense world covered in acorn trees. Filled with wonder, he threw himself into the void… However, as he was quite inexperienced in multi-dimensional travel, he found himself cast out on an alien world instead. There, he was rescued by a human visiting that world, named Prism, who carried the mark of a powerful and venerable force of protectors. Prism was unable to take Sunbeam back to Earth, and instead too him with him to his headquarters, where soon, he, too, was granted the same powers in order to return to Earth. Instead of going straight back, though, he decided to stick by the side of his rescuer… At least for awhile."},{"id":24,"name":"market place 1","type":"marketplace","image":"images/my_heros1.png","faction":"Green","tier":5,"tokenId":563,"isOnSale":true,"sellPrice":3243253,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43434232,"rating":2,"level":"latest","description":"Description placement"},{"id":25,"name":"market place 2","type":"marketplace","image":"images/my_heros1.png","faction":"Blue","tier":5,"tokenId":563,"isOnSale":true,"sellPrice":3243253,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43434232,"rating":2,"level":"latest","description":"Description 33"},{"id":26,"name":"market place 3","type":"marketplace","image":"images/my_heros1.png","faction":"Red","tier":5,"tokenId":563,"isOnSale":true,"sellPrice":3243253,"owner":"0x20d887B4Cbf638e62ff7127D72678cDb727343a8","lastFightBlock":43434232,"rating":2,"level":"latest","description":"Description 55"}],"userInfo":{"totalFights":10,"image":"images/mp_gallary_img.png","totalWon":4,"pendingRewards":"$3","totalRewards":"15$","lastClaim":24324343332,"referralCode":4343,"pendingReferralRewards":"$10","totalReferralRewards":"$123","totalReferrals":200,"cooldownPotions":2,"boostPotions":4},"claimTax":25}`;
nftData = JSON.parse(nftData);
let nft_arr = nftData.nfts;
let userInfo = nftData.userInfo;
let pageNumber = 1;

let _url = window.location.pathname;
let urlPageName = get_file_name(_url.substring(_url.lastIndexOf('/') + 1)).filename;
function get_file_name(url) {
    url = url.split('/').pop().replace(/\#(.*?)$/, '').replace(/\?(.*?)$/, '');
    url = url.split('.');
    return {filename: (url[0] || ''), ext: (url[1] || '')}
}


nft_arr = getNftDataByType(urlPageName);
console.log("data____", nft_arr);
 
console.log("nftData", nftData);


function getPageName(urlPageName){

}

function getNftDataByType(urlPageName){

    let nftTypeFilterData = [];
	if(urlPageName == "marketplace") {
	 nftTypeFilterData =    nft_arr.filter(obj => obj.type == "marketplace");

	}else if(urlPageName == "my_heroes"){
		nftTypeFilterData =    nft_arr.filter(obj => obj.type == "hero");
	}
    return nftTypeFilterData;

}


$( document ).ready(function() {


    loadNftData([],'');

    let pageName = $(".hidden_page_name").val();
    $("body").on("click",".nft_li_content",function(){
        
        let pageName = $(this).attr('data-page-name');
        let id = $(this).attr('data-id');
       
        getNftDetailPanel(id,pageName);
    });

    $("body").on("keyup",".nft_page_number",function(){
        let page = $(this).val();
        let totalPages = $(".nft_total_pages").text();
        loadNftData([],'',page);

    });
    
     $("body").on("click",".mp_pagi_next_btn",function(){ 
        let pageNumber =  parseInt($(".nft_page_number").val());
        pageNumber = pageNumber+1;
        let totalPages = parseInt($('.nft_total_pages').text());
        if(pageNumber <= totalPages){
            $(".nft_page_number").val(pageNumber);
            loadNftData([],'',pageNumber);
        }
        
     });

     $("body").on("click",".mp_pagi_rev_btn",function(){ 
        let pageNumber =  parseInt($(".nft_page_number").val());
        pageNumber = pageNumber-1;
        if(pageNumber != 0){
            $(".nft_page_number").val(pageNumber);
            loadNftData([],'',pageNumber);
        }
        
     });
    

    $("body").on("keyup",".search_input_nft_data", function(){ 
      
          let keyword = $(this).val();

          filterNftData(keyword,pageName,'name');
            
     });

    $("body").on("click",".filter_selection_box", function(){ 
        let dataId = $(this).attr('data-id');
        let type = $(this).attr('data-type');
        filterNftData(dataId,pageName,'boxes_filter');
    }); 

    $("body").on("change",".sel_filter_rating", function(){ 

        let value = $(this).val();
        filterNftData(value,pageName,'rating_filter');
    });
     
    $("body").on("change",".sel_filter_level", function(){ 

        let value = $(this).val();
        filterNftData(value,pageName,'level_filter');
    }); 

     
    


});


function findFromArray(array,key,value) {
        return array.filter(function (element) {
            return element[key] == value;
        }).shift();
}

function getRatingHtml(rating){

    let ratingHtml = '';
    if(rating == 1){
        ratingHtml =   `<i class="mh_galary_star"></i>`;
    }else if(rating == 2){
        ratingHtml +=   `<i class="mh_galary_star"></i>`;
        ratingHtml +=   `<i class="mh_galary_star"></i>`;
    }else if(rating == 3){

        ratingHtml +=   `<i class="mh_galary_star"></i>`;
        ratingHtml +=   `<i class="mh_galary_star"></i>`;
        ratingHtml +=   `<i class="mh_galary_star"></i>`;

    }else if(rating == 4){

        ratingHtml +=   `<i class="mh_galary_star"></i>`;
        ratingHtml +=   `<i class="mh_galary_star"></i>`;
        ratingHtml +=   `<i class="mh_galary_star"></i>`;
        ratingHtml +=   `<i class="mh_galary_star"></i>`;

    }else if(rating == 5){

        ratingHtml +=   `<i class="mh_galary_star"></i>`;
        ratingHtml +=   `<i class="mh_galary_star"></i>`;
        ratingHtml +=   `<i class="mh_galary_star"></i>`;
        ratingHtml +=   `<i class="mh_galary_star"></i>`;
        ratingHtml +=   `<i class="mh_galary_star"></i>`;

    }

    return ratingHtml;
}

function loadNftData(filterNftData,keyword,pageNumber){

   let nfts = nft_arr;
   let paginatorData = paginator(nfts,parseInt(pageNumber));
   nfts = paginatorData.data;
   if($.trim(keyword) != ""){
      nfts = filterNftData;
      paginatorData = paginator(nfts,parseInt(pageNumber));
   }
   let heroPageHtml = '';
   $(".hero_content_ul").html('');
   for (let i = 0; i < nfts.length; i++) {
       let single = nfts[i];
       let rating_html = getRatingHtml(single.rating);

       if(urlPageName == "my_heroes") {

               heroPageHtml += `<li data-id="${single.id}" data-page-name="hero" class="mh_galary_list nft_li_content" data-type="all" data-level="12">
                            <div class="mh_galary_box  ">
                                <a class="" href="javascript:void(0)">
                                    <figure><img src="${single.image}" alt="#"></figure>

                                    <div class="mh_galary_price">
                                        <div class="mh_galary_stars">
                                            ${rating_html}
                                        </div>
                                        <small>${single.name}</small>
                                    </div>
                                </a>
                            </div>
                        </li>`;

       }else if(urlPageName == "marketplace"){

       		heroPageHtml += `<li data-id="${single.id}" data-page-name="marketplace" class="mp_galary_list nft_li_content" data-type="all" data-level="12">
                                <div class="marketPlace_galary_box">
                                    <a href="javascript:void(0)">
                                        <i class="mp_normal"><img src="images/mp_gallary_img.png" alt="#"></i>
                                        <span class="mp_gallary_price">Glr 999,999,999</span>
                                    </a>
                                </div>
                            </li>`;

       }
      


   }
   $(".hero_content_ul").html(heroPageHtml);
   $(".mp_pagi_numbers").find('.nft_page_number').val(paginatorData.page);
   $(".mp_pagi_numbers").find('.nft_total_pages').text(paginatorData.total_pages);

   let pageName = $(".hidden_page_name").val();
   if(pageName == "heroes"){
        setTimeout(function() {
          $("html, body").removeClass('open_right_panel');
       }, 200);
   }
   
}

function getNftDetailPanel(id,pageName){


   let nftArray =  nft_arr;
   let userInfo =  nftData.userInfo;
   let singleNft = findFromArray(nftArray,'id',id);
   let rating = singleNft.rating;
   let ratingHtml = getRatingHtml(rating);


    console.log("pageName", pageName);
    console.log("nftArray", singleNft);

   let rightPanelHtml = '';
   if(singleNft != undefined) {
        rightPanelHtml = `<div class="right_panel">
                              <div class="panel_close">
                                <i></i>
                              </div>
                             <div class="panel_box">
                                <div class="panel_headline">
                                    <h2>${singleNft.name}</h2>
                                    <div class="rb_mh_stars">
                                        ${ratingHtml}
                                    </div>
                                </div>
                                <div class="panel_box_content">
                                    <div class="rb_fighters_row">
                                        <div class="rb_fighters_img">
                                            <img src="${userInfo.image}" alt="#">
                                        </div>
                                        <div class="rb_fighters_info">
                                            
                                            <div class="rbf_info_box">
                                                <ul>
                                                    <li>
                                                        <div class="rbf_info_row">
                                                            <span>Total Fights</span>
                                                            <strong><i>${userInfo.totalFights}</i></strong>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="rbf_info_row">
                                                            <span>RARITY</span>
                                                            <strong><i>${userInfo.totalReferrals}</i></strong>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="rbf_info_row">
                                                            <span>WORLD</span>
                                                            <strong><i>${userInfo.totalReferrals}</i></strong>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>

                                            <div class="rbf_phonex_box">
                                                <p>${singleNft.description}</p>
                                            </div>

                                        </div>
                                    </div>

                                    <div class="rb_buyRow">

                                        <div class="rbf_info_box mh_cancel_listing_box">
                                            <ul>
                                                <li>
                                                    <div class="rbf_info_row">
                                                        <span>99,999,999  GLR</span>
                                                        <a class="all_btn all_blue mh_complete_listing_btn" href="javascript:void(0)"><i>complete listing</i></a>
                                                        <a class="all_btn mh_cancel_listing_btn" href="javascript:void(0)"><i>Cancel listing</i></a>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>

                                        <div class="rbf_info_box mh_sell_listing_box">
                                            <ul>
                                                <li>
                                                    <div class="rbf_info_row">
                                                        <a class="all_btn all_blue mh_sell_listing_btn" href="javascript:void(0)"><i>Sell</i></a>

                                                        <a class="all_btn  mh_enterbattle_btn" href="play_area.html"><i>Enter battle</i></a>

                                                        <a class="all_lable mh_sell_time_btn" href="javascript:void(0)"><i>12 : 56 : 30</i></a>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>`;
   }

   

     $(".right_panel_main").html(rightPanelHtml);
}

function filterNftData(keyword,pageName,searchType){

   let nftArray =  nft_arr;
   let filterNftData =    nftArray.filter(o => o.name.includes(keyword));

   

   console.log("keyword ", keyword);

   if (searchType == "boxes_filter") {

        keyword =  capitalizeFirstLetter(keyword);
        filterNftData =    nftArray.filter(o => o.faction.includes(keyword));

   }else if(searchType == "rating_filter"){

        keyword = parseInt(keyword);
        filterNftData =    nftArray.filter(ob => ob.rating == keyword);
   }else if(searchType == "level_filter"){

        keyword = keyword;
        filterNftData =    nftArray.filter(o => o.level == keyword);
   }
  
   console.log("filterNftData : ", filterNftData);

   loadNftData(filterNftData,keyword);
 
}

function capitalizeFirstLetter(str) {

    // converting first letter to uppercase
    const capitalized = str.replace(/^./, str[0].toUpperCase());
    return capitalized;
}

function paginator(items, page, per_page) {

  var page = page || 1,
  per_page = per_page || 10,
  offset = (page - 1) * per_page,

  paginatedItems = items.slice(offset).slice(0, per_page),
  total_pages = Math.ceil(items.length / per_page);
  return {
  page: page,
  per_page: per_page,
  pre_page: page - 1 ? page - 1 : null,
  next_page: (total_pages > page) ? page + 1 : null,
  total: items.length,
  total_pages: total_pages,
  data: paginatedItems
  };

}
