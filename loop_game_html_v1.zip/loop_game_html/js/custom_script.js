
 
 
$(document).ready(function(e) { 

	$("body").on("click",".selectbox_span",function(e){
		e.stopPropagation();
		 $('.selectbox').removeClass("focus");
		$(this).parent().addClass("focus");
		$('.selectbox_dropdown').hide();
		 $(this).parent().find('.selectbox_dropdown').show();
	});
   

	 $("body").on('click', function() {
	  $('.selectbox_dropdown').hide();
   });
   
   $("body").on("click",".selectbox_dropdown li",function(){
	   if($(this).hasClass("not_click"))
	   {
		   return false;
	   }
	   var optionHtml = $(this).html();
		$(this).closest(".selectbox").addClass("selected");
	   $(this).closest(".selectbox").find(".active").removeClass("active");
	   $(this).addClass("active");
		$(this).closest(".selectbox").find("span").html(optionHtml);
	});

	$("body").on("focusin",".selectbox select",function(e){
		 $('.selectbox').removeClass("focus");
		 $(this).parent().addClass("focus");
	});
	$("body").on("click",".selectbox select",function(e){
		$('.selectbox').removeClass("focus");
		$(this).parent().addClass("focus");
   });
	$("body").on("focusout",".selectbox select",function(e){
		$('.selectbox').removeClass("focus");
   });
   
	$("body").on("change",".selectbox select",function(e){
		var slctVal = $(this).find(":selected").text();
		$(this).parent().find("span").text(slctVal);
		$(this).closest(".selectbox").addClass("selected");
		setTimeout(function(){
			$('.selectbox').removeClass("focus");
		},100);
	});
 
	

	///////////////////
	


 
	$("body").on("click",".themeBox",function(){
		 $('.themeBox').removeClass("active");
		 $(this).addClass("active");
		 var rel = $(this).attr('data-rel');
		 console.log(rel);
		 $(".playAreaBody").css({"background-image": "url(" + rel + ")"});
    });

	$("body").on("click",".themeBarRight .all_btn",function(){
		$('.themeMain').addClass("hidden");
		$('.playAreaBody').addClass("readytoplay");

		setTimeout(function(){
			$('.playAreaBody').removeClass("readytoplay");
			setTimeout(function(){
				$('.result_victory').show(function(){
					$('.result_victory').addClass("active");
				});
			},1000);
		},3000);



   });
   
   $("body").on("click",".filters_link",function(){
		$(this).closest('.filters_menu').find('.filters_link').removeClass("active");
		$(this).addClass('active');
	});

	
   
   $("body").on("click",".marketPlace_galary .marketPlace_galary_box a, .marketPlace_galary .mh_galary_box a",function(){
		$('body, html').addClass("open_right_panel");
		$('.marketPlace_galary_box a').removeClass("active");
		$(this).addClass('active');
		var vw = $(window).width();
	    $('.marketPlace_galary ul').css('min-width', vw);
	});

   $("body").on("click",".panel_close",function(){
    	$('.marketPlace_galary_box a').removeClass("active");
		$('body, html').removeClass("open_right_panel");
		setTimeout(function(){
			$('.marketPlace_galary ul').css('min-width', 0);
		},500);
	});

	$("body").on("click",".mh_galary_box",function(){
		//$('body, html').addClass("open_right_panel");
		//$('.mh_galary_box').removeClass("active");
		$(this).closest("ul").find(".mh_galary_box").removeClass("active");
		$(this).addClass('active');
	});

	$("body").on("click",".mh_sell_listing_btn",function(){
    	$('.mh_enterbattle_btn').hide();
		$('.mh_sell_time_btn').fadeIn();
		$(this).addClass('mh_sell_readdy_btn');
	});
	
	$("body").on("click",".mh_sell_readdy_btn",function(){
    	$('.mh_sell_listing_box').hide();
		$('.mh_cancel_listing_box').fadeIn();
		$('.mh_sell_listing_btn').removeClass('mh_sell_readdy_btn');
	});

	$("body").on("click",".mh_complete_listing_btn",function(){
    	$('.mh_complete_listing_btn').hide();
		$('.mh_cancel_listing_btn').fadeIn();
	});

	$("body").on("click",".mh_cancel_listing_btn",function(){
    	$('.mh_cancel_listing_btn, .mh_sell_time_btn').hide();
		$('.mh_complete_listing_btn, .mh_enterbattle_btn').fadeIn();
		$('.mh_cancel_listing_box').hide();
		$('.mh_sell_listing_box').fadeIn();
	});


	
	$("body").on("click",".menu_close",function(){
		$('body, html').removeClass("isOpenMenu");
		$(".menuIcon").removeClass("open");
	});

	$("body").on("click",".menuIcon",function(){
		if($('body, html').hasClass("isOpenMenu"))
		{
			$('body, html').removeClass("isOpenMenu");
			$(".menuIcon").removeClass("open");
		}else{
			$('body, html').addClass("isOpenMenu");
			$(".menuIcon").addClass("open");
		}
	});
	

	$("body").click(function (e) {
        if (!$(e.target).is('.header_menu_main, .header_menu_main *, .menuIcon, .menuIcon *')) {
			$('body, html').removeClass("isOpenMenu");
			$(".menuIcon").removeClass("open");
        }
    });

	$("body").on("click",".mob_filter_search",function(){
		if($(this).closest('.filters_box').hasClass("open_search"))
		{
			$(this).closest('.filters_box').removeClass("open_search");
		}else{
			$(this).closest('.filters_box').addClass("open_search");
		}
	});

	$("body").click(function (e) {
        if (!$(e.target).is('.filters_box, .filters_box *, .mob_filter_search, .mob_filter_search *')) {
			$('.filters_box').removeClass("open_search");
        }
    });



	

	$("body").on("click",".gmvs_mob_tab_btn",function(){
		var parent = $(this).closest('ul');
		if($(this).hasClass("gmvs_mob_heros"))
		{
			$(".gmvs_right").removeClass("active").addClass("is_hide");
			$(".gmvs_left").addClass("active");
			$(parent).find(".gmvs_mob_animy").removeClass('active');
			$(parent).find(".gmvs_mob_heros").addClass('active');
		}else{
			$(".gmvs_left").removeClass("active").addClass("is_hide");
			$(".gmvs_right").addClass("active");
			$(parent).find(".gmvs_mob_heros").removeClass('active');
			$(parent).find(".gmvs_mob_animy").addClass('active');
		}
	});


	$("body").on("click", ".pet_play_tabs_nav ul li a", function (e) {
        var tabClass = $(this).attr("data-rel");
        $(".pet_play_tabs_nav ul li a").removeClass("active");
        $(".pet_play_tabs_content").hide();
        $(this).addClass("active");
        $(tabClass).show();
        return false;
    });
 
	$("body").on("click", ".dashboard_tabs_nav ul li a", function (e) {
        var tabClass = $(this).attr("data-rel");
        $(".dashboard_tabs_nav ul li a").removeClass("active");
        $(".dashboard_tabs_content").hide();
        $(this).addClass("active");
        $(tabClass).show();
        return false;
    });

	


	// $('.filter-button').on("click", function() {
	// 	var data_type = $(this).attr('data-type');
	// 	var data_value = $(this).attr('data-value');
	// 	$("[data-type="+data_type+"]").removeClass('active');
	// 	$(this).addClass('active');
	// 	$('.mh_galary_list').hide().removeClass('active');
	// 	var classesArray = [];
	// 	$('.filters_link.active').each(function(){
	// 	   var selected_filters = $(this).attr('data-value');
	// 	   classesArray.push(selected_filters);
	// 	})
	// 	classes = classesArray.join('.');
	// 	$('.'+classes).show();
	// });

   
	
 

 //end ready
 });
 
 
  
 
//  $(window).scroll(function(){
// 	var sticky = $('.hg_header, .hg_wrapper')
// 	scroll = $(window).scrollTop();
// 	if (scroll >= 0){
// 		sticky.addClass('fixed');
// 			setTimeout(function(){
// 			sticky.addClass('animate'); 			   
// 		},100)
// 	}else {
// 		sticky.removeClass('fixed animate');
// 	}
 	
//  });


$(window).resize(function(){
	var vw = $(window).width();
	 $('.marketPlace_galary ul').css('min-width', vw);
});



function splash_loader(){
	document.onreadystatechange = function(e)
    {
        if(document.readyState=="interactive")
        {
            var all = document.getElementsByTagName("*");
            document.getElementById("progress_div").style.display="block";
            for (var i=0, max=all.length; i < max; i++) 
            {
                set_ele(all[i]);
            }
        }
    }
    function check_element(ele)
    {
        var all = document.getElementsByTagName("*");
        var totalele=all.length;
        var per_inc=100/all.length;
    
        if($(ele).on())
        {
            var prog_width=per_inc+Number(document.getElementById("progress_width").value);
            document.getElementById("progress_width").value=prog_width;
            $("#bar1").animate({width:prog_width+"%"},10,function(){
                if(document.getElementById("bar1").style.width=="100%")
                {
                    $(".progress").fadeOut("slow");
                }			
            });
    
        }
        else	
        {
            set_ele(ele);
        }
    }
    function set_ele(set_element)
    {
        check_element(set_element);
    }
    
}
 

 
 
 

 